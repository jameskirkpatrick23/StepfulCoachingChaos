import React, {useEffect, useState} from 'react';
import { useAppContext } from '../contexts/appContext.js';
import {createCoachAppointment, fetchCoachAppointments, updateCoachAppointment} from '../contexts/APICalls.js';

function FeedbackForm({ appointment, onSave, students }) {
    const [notes, setNotes] = useState(appointment.notes);
    const [rating, setRating] = useState(appointment.rating);
    const foundStudent = students.find(x => x.id === appointment.student_id)
    return (
        <div className="p-2 border mb-2">
            <div>
                <div><strong>{appointment.day} at {appointment.hour}:00</strong></div>
                <div className="italic mb-1">{foundStudent.first_name} {foundStudent.last_name}</div>
            </div>
            <textarea
                rows={3}
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="Write notes..."
                className="w-full p-1 mb-2 bg-gray-100"
            />
            <span>Student Satisfaction: </span>
            <input
                type="number"
                min={1}
                max={5}
                value={rating}
                onChange={e => setRating(Number(e.target.value))}
                className="p-1 w-16 mr-2"
            />
            <button onClick={() => onSave(appointment, notes, rating)} className="px-3 py-1 bg-green-500 text-white rounded float-right">Save</button>
        </div>
    );
}

function UpcomingStudentBooking({appointment, students}) {
    const foundStudent = students.find(x => x.id === appointment.student_id)

    return (
        <div>
            <p className="mb-1">Booked by <strong>{foundStudent.first_name} {foundStudent.last_name}</strong></p>
            <p className="mb-1"><strong>Phone: </strong>{foundStudent.phone}</p>
            <p className="mb-1"><strong>Email: </strong>{foundStudent.email}</p>
        </div>
    )
}

export function CoachDashboard() {
    const { appointments, setAppointments, currentUser, students } = useAppContext();
    const [day, setDay] = useState('');
    const [hour, setHour] = useState('00');

    useEffect(() => {
        fetchCoachAppointments(currentUser.id, setAppointments);
    }, []);

    function formatMDY(dateStr) {
        const [y, m, d] = dateStr.split('-');
        return `${y}-${m}-${d}`;
    }

    const today = new Date();
    const todayMDY = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;

    function addSlot() {
        if (!day) return;
        const newAppointment = {
            day: formatMDY(day),
            hour,
            student_id: null,
            coach_id: currentUser.id,
            rating: 0,
            notes: ''
        };
        setAppointments(prev => [...prev, newAppointment]);
        // Optionally POST to backend:
        createCoachAppointment(currentUser.id, newAppointment);

    }

    const upcoming = appointments.filter(a => a.coach_id === currentUser.id && a.day >= todayMDY);
    const past = appointments.filter(a => a.coach_id === currentUser.id && a.day < todayMDY && a.student_id);

    function saveFeedback(appointment, notes, rating) {
        setAppointments(
            appointments.map(a => a.id === appointment.id ? { ...a, notes, rating } : a)
        );
        // Optionally PATCH to backend:
        updateCoachAppointment(currentUser.id, {...appointment, notes, rating}, setAppointments);
    }

    return (
        <div>
            <section className="mb-8">
                <h2 className="text-xl mb-2">Add Availability</h2>
                <input type="date" value={day} onChange={e => setDay(e.target.value)} className="border p-1 mr-2" />
                <select value={hour} onChange={e => setHour(e.target.value)} className="border p-1 mr-2">
                    {[...Array(24).keys()].filter(h=>h%2===0).map(h => {
                        const hh = String(h).padStart(2,'0');
                        return <option key={h} value={hh}>{hh}:00</option>;
                    })}
                </select>
                <button onClick={addSlot} className="px-3 py-1 bg-blue-500 text-white rounded">Add Slot</button>
            </section>

            <section className="mb-8">
                <h2 className="text-xl mb-2">Upcoming Slots</h2>
                {!upcoming.length && <p>No upcoming slots</p>}
                {upcoming.map(a => (
                    <div key={`${a.id}-${currentUser.id}-${a.day}-${a.hour}`} className="p-2 border mb-2">
                        <div><strong>{a.day} at {a.hour}:00</strong></div>
                        {a.student_id && <UpcomingStudentBooking key={`booked-appointment-${a.id}`} appointment={a} students={students} />}
                    </div>
                ))}
            </section>

            <section>
                <h2 className="text-xl mb-2">Past Calls & Feedback</h2>
                {!past.length && <p>No past calls with feedback</p>}
                {past.map(a => (
                    <FeedbackForm key={a.id} appointment={a} onSave={saveFeedback} students={students}/>
                ))}
            </section>
        </div>
    );
}
