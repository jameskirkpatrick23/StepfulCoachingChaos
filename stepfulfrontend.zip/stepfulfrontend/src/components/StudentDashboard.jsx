import React, {useEffect} from 'react';
import { useAppContext } from '../contexts/appContext.js';
import {
    bookStudentAppointment,
    fetchAvailableAppointments,
    fetchStudentAppointments,
} from '../contexts/APICalls.js';

export function StudentDashboard() {
    const { appointments, availableAppointments, setAppointments, setAvailableAppointments, currentUser, coaches } = useAppContext();
    const today = new Date();
    const todayMDY = `${String(today.getMonth()+1).padStart(2,'0')}/${String(today.getDate()).padStart(2,'0')}/${today.getFullYear()}`;

    const available = availableAppointments.filter(a => a.day >= todayMDY);
    const myBookings = appointments.filter(a => a.student_id === currentUser.id);

    useEffect(() => {
        // my appointments
        fetchStudentAppointments(currentUser.id, setAppointments);
        fetchAvailableAppointments(setAvailableAppointments);
    }, []);

    function bookSlot(appointment) {
        setAppointments(
            appointments.map(a => a.id === appointment.id ? { ...a, student_id: currentUser.id } : a)
        );
        // Optionally PATCH to backend:
        bookStudentAppointment(currentUser.id, appointment, setAppointments, setAvailableAppointments);
    }

    function getCoach(id) {
        return coaches.find(c => c.id === id) || {};
    }

    return (
        <div>
            <section className="mb-8">
                <h2 className="text-xl mb-2">Available Slots</h2>
                {!available.length && <p>No available slots</p>}
                {available.map(a => {
                    const coach = getCoach(a.coach_id);
                    return (
                        <div key={a.id} className="p-2 border mb-2 flex justify-between items-center">
                            <div>
                                <div><strong>{a.day} at {a.hour}:00</strong></div>
                                <div><strong>Coach:</strong> {coach.first_name} {coach.last_name}</div>
                            </div>
                            <button onClick={() => bookSlot(a)} className="px-3 py-1 bg-blue-500 text-white rounded">Book</button>
                        </div>
                    );
                })}
            </section>

            <section>
                <h2 className="text-xl mb-2">My Bookings</h2>
                {!myBookings.length && <p>No bookings yet</p>}
                {myBookings.map(a => {
                    const coach = getCoach(a.coach_id);
                    return (
                        <div key={a.id} className="p-2 border mb-2">
                            <div><strong>{a.day} at {a.hour}:00</strong></div>
                            <div><strong>Coach Name:</strong> {coach.first_name} {coach.last_name}</div>
                            <div><strong>Phone:</strong> {coach.phone}</div>
                            <div><strong>Email:</strong> {coach.email}</div>
                        </div>
                    );
                })}
            </section>
        </div>
    )
}