export const fetchCoaches = (setCoaches) => {
    fetch(`http://localhost:3000/coaches`)
        .then(res => res.json())
        .then(data => setCoaches(data))
        .catch(err => console.error('Error fetching coaches:', err));
}

export const fetchCoachAppointments = (coachId, setAppointments) => {
    fetch(`http://localhost:3000/coaches/${coachId}/appointments`)
        .then(res => res.json())
        .then(data => setAppointments(data))
        .catch(err => console.error('Error fetching appointments for current coach:', err));
}

export const createCoachAppointment = (coachId, newAppointment) => {
    fetch(`http://localhost:3000/coaches/${coachId}/appointments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({appointment: newAppointment})
    }).catch(err => console.error('Error creating appointment:', err));
}

export const updateCoachAppointment = (coachId, appointmentData, setAppointments) => {
    fetch(`http://localhost:3000/coaches/${coachId}/appointments/${appointmentData.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appointment: appointmentData })
    })
    .then(() => fetchCoachAppointments(coachId, setAppointments))
    .catch(err => console.error('Error updating appointment:', err));
}

export const fetchStudents = (setStudents) => {
    fetch('http://localhost:3000/students')
        .then(res => res.json())
        .then(data => setStudents(data))
        .catch(err => console.error('Error fetching students:', err));
}

export const fetchStudentAppointments = (studentId, setAppointments) => {
    fetch(`http://localhost:3000/students/${studentId}/appointments`)
        .then(res => res.json())
        .then(data => setAppointments(data))
        .catch(err => console.error('Error fetching appointments for current student:', err));
}

export const fetchAvailableAppointments = (setAvailableAppointments) => {
    fetch(`http://localhost:3000/appointments`)
        .then(res => res.json())
        .then(data => setAvailableAppointments(data))
        .catch(err => console.error('Error fetching available for current student to book:', err));
}

export const bookStudentAppointment = (studentId, appointment, setAppointments, setAvailableAppointments) => {
    fetch(`http://localhost:3000/students/${studentId}/appointments/${appointment.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appointment: { ...appointment, student_id: studentId } })
    }).then(() => {
        fetchStudentAppointments(studentId, setAppointments);
        fetchAvailableAppointments(setAvailableAppointments);
    }).catch(err => console.error('Error booking slot:', err));
}

