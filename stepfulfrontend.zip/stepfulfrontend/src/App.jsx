// File: src/App.jsx
import React, { useState, useEffect } from 'react';
import { CoachDashboard } from './components/CoachDashboard';
import { StudentDashboard } from './components/StudentDashboard';
import { AppContext } from './contexts/appContext.js';
import {fetchCoaches, fetchStudents} from './contexts/APICalls.js';

export default function App() {
    const [role, setRole] = useState(null);
    const [currentUser, setCurrentUser] = useState(null);
    const [coaches, setCoaches] = useState([]);
    const [students, setStudents] = useState([]);
    const [appointments, setAppointments] = useState([]);
    const [availableAppointments, setAvailableAppointments] = useState([]);

    // Fetch data from Rails API on mount
    useEffect(() => {
        fetchCoaches(setCoaches);
        fetchStudents(setStudents);
    }, []);

    const ContextValues = { coaches, students, appointments, setAppointments, availableAppointments, setAvailableAppointments, currentUser, role };

    if (!role) {
        return (
            <div className="p-8">
                <h1 className="text-2xl mb-4">Select Role</h1>
                <button onClick={() => setRole('coach')} className="px-4 py-2 mr-2 bg-blue-500 text-white rounded">Coach</button>
                <button onClick={() => setRole('student')} className="px-4 py-2 bg-green-500 text-white rounded">Student</button>
            </div>
        );
    }

    if (!currentUser) {
        const list = role === 'coach' ? coaches : students;
        return (
            <div className="p-8">
                <h1 className="text-2xl mb-4">Select {role === 'coach' ? 'Coach' : 'Student'}</h1>
                {list.map((user) => (
                    <button
                        key={user.id}
                        onClick={() => setCurrentUser(user)}
                        className="block mb-2 px-4 py-2 bg-gray-200 rounded w-48 text-left"
                    >
                        {user.first_name} {user.last_name}
                    </button>
                ))}
                <button onClick={() => setRole(null)} className="mt-4 text-red-500">Back</button>
            </div>
        );
    }

    return (
        <AppContext.Provider value={ContextValues}>
            <div className="p-8">
                <div className="flex justify-between items-center mb-6">
                    <h1 className="text-2xl">Welcome, {currentUser.first_name}</h1>
                    <button
                        onClick={() => { setRole(null); setCurrentUser(null); }}
                        className="px-3 py-1 bg-red-400 text-white rounded"
                    >Logout</button>
                </div>
                {role === 'coach' && currentUser ? <CoachDashboard /> : <div></div>}
                {role === 'student' && currentUser ? <StudentDashboard />: <div></div>}
            </div>
        </AppContext.Provider>
    );
}

// Don't forget to import components in App.jsx
