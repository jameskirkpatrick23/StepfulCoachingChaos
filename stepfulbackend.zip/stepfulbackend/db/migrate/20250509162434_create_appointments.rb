class CreateAppointments < ActiveRecord::Migration[8.0]
  def change
    create_table :appointments do |t|
      t.date :day, null: false
      t.string :hour, null: false
      t.references :student, null: true, foreign_key: true
      t.references :coach, null: false, foreign_key: true
      t.integer :rating
      t.text :notes

      t.timestamps
    end
  end
end
