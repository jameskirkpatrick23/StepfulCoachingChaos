# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).

future_appointments = []
past_appointments = []
students = []
["CoachOne@gmail.com", "CoachTwo@gmail.com", "CoachThree@gmail.com"].each_with_index do |email, index|
  coach = Coach.create(email: email, first_name: "Coach#{index + 1}", last_name: "Number#{index + 1}", phone: "#{(index + 1) * 100}-123-1234")

  4.times do |subindex|
    hours = 6 + 2 * subindex
    d = Time.new.to_date
    d2 = Time.new.to_date - (subindex + 1)

    a = Appointment.create(day: d.strftime("%F"), hour: hours, coach_id: coach.id, student_id: nil, rating: 0, notes: '')
    future_appointments.push(a)
    a2 = Appointment.create(day: d2.strftime("%F"), hour: hours, coach_id: coach.id, student_id: nil, rating: 0, notes: '')
    past_appointments.push(a2)
  end
end

["StudentOne@gmail.com", "StudentTwo@gmail.com", "StudentThree@gmail.com", "StudentFour@gmail.com"].each_with_index do |email, index|
  first_name = "Student #{index + 1}"
  last_name = "Number #{index + 1}"
  s = Student.create(email: email, first_name: first_name, last_name: last_name, phone: "#{(index + 1) * 100}-123-1234")
  students.push(s)
end

past_appointments.each_with_index do |a, index|
  s = Student.find(Student.pluck(:id).sample)

  prng = Random.new
  rating = prng.rand(1..5)
  experiences = [
    'a difficult time working through the session. Another session will be required.',
    'some issues early on in the session, but progress was made in learning the material. Another session is recommended.',
    'a fine session, the material was covered and the student will follow up with more questions. Another session is recommended.',
    'a very good session, the student seemed to grasp the material well, and will follow up if they have more questions on their own time. No further sessions on the subject are recommended.',
    'a wonderful session, the student took exceptionally well to the material and demonstrated high competency by the completion of the alotted time. Student will follow up if they have more questions in the future. No further sessions on the subject are recommended.',
  ]
  a.update(student: s, rating: rating, notes: "#{s.name} and #{a.coach.name} had #{experiences[rating - 1]}. ")
end

