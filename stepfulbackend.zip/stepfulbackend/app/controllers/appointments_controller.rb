class AppointmentsController < ApplicationController
  before_action :set_appointment, only: %i[ show update destroy ]
  before_action :set_coach, only: %i[ index show create update destroy ]
  before_action :set_student, only: %i[ index show update ]

  # GET /appointments
  def index
    if @student #/students/1/appointments get appointments the student has booked
      @appointments = Appointment.where(student_id: @student.id).order(day: :desc)
    elsif @coach #/coaches/1/appointments get appointments the coach has ever made
      @appointments = Appointment.where(coach_id: @coach.id).order(day: :desc)
    else #/appointments get all appointments available still
      @appointments = Appointment.where(student_id: nil).order(day: :desc)
    end
    render json: @appointments
  end

  # GET /appointments/1
  def show
    render json: @appointment
  end

  # POST /appointments
  def create
    is_valid_timeslot = validate_appointment_time(appointment_params, @coach, nil)
    if is_valid_timeslot
      @appointment = Appointment.new(appointment_params)
      puts "@appointment #{@appointment}"
      if @appointment.save
      puts "@appointment  save? #{@appointment}"
        render json: @appointment, status: :created, location: @appointment
      else
      puts "@appointment  errors? #{@appointment.errors.full_messages}"
        render json: @appointment.errors, status: :unprocessable_entity
      end
    else
      puts "????? #{@appointment.errors}"
      render json: { errors: { timeslot_conflict: is_valid_timeslot } }, status: :bad_request
    end
  end

  # PATCH/PUT /coaches/1/appointments/1
  # PATCH/PUT /students/1/appointments/1
  def update
    if !@coach
      @coach = Coach.find(appointment_params[:coach_id])
    end
    is_valid_timeslot = validate_appointment_time(appointment_params, @coach, @appointment.id)
    if is_valid_timeslot
      if @appointment.update(appointment_params)
        render json: @appointment
      else
        render json: @appointment.errors, status: :unprocessable_entity
      end
    else
      render json: { errors: { timeslot_conflict: is_valid_timeslot } }, status: :bad_request
    end
  end

  # DELETE /appointments/1
  def destroy
    @appointment.destroy!
  end

  private
    # Use callbacks to share common setup or constraints between actions.

    def set_coach
      if params[:coach_id]
        @coach = Coach.find(params[:coach_id])
      end
    end

    def set_student
      if params[:student_id]
        @student = Student.find(params[:student_id])
      end
    end

    def set_appointment
      @appointment = Appointment.find(params.expect(:id))
    end

    def validate_appointment_time(appointment_params, coach, existing_appointment_id)
      date = Date.parse(appointment_params[:day])
      appointments_with_same_day = Appointment.where(coach_id: coach.id, day: date, hour: (appointment_params[:hour].to_i - 1)..(appointment_params[:hour].to_i + 1))
      is_valid_time = true
      if !appointments_with_same_day.empty?
        if appointments_with_same_day.length > 1 || appointments_with_same_day.first.id != existing_appointment_id
          is_valid_time = false
        end
      end
      is_valid_time
    end

    # Only allow a list of trusted parameters through.
    # day should only care about day, month, year
    # timeslot is offered on UI as 6am, 8am, 10am, 12(noon pm), and sent to controller as 24 hour integer
    # 2pm = 14 6pm = 18 etc.
    def appointment_params
      params.expect(appointment: [ :day, :hour, :student_id, :coach_id, :rating, :notes ])
    end
end
