class Coach < ApplicationRecord
  has_many :appointments, dependent: :destroy
  has_many :students, through: :appointments

  def name
    self.first_name + " " + self.last_name
  end
end
