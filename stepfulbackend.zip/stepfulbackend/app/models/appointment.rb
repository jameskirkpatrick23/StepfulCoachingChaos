class Appointment < ApplicationRecord
  belongs_to :student, optional: true
  belongs_to :coach
end
